package org.aguzman.poointerfaces.repositorio;

public interface OrdenablePaginableCrudRepositorio extends OrdenableRepositorio,
                        PaginableRepositorio, CrudRepositorio, ContableRepositorio {
}
