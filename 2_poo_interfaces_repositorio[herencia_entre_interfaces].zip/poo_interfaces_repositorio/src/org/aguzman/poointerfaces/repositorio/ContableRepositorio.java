package org.aguzman.poointerfaces.repositorio;

public interface ContableRepositorio {
    int total();
}
