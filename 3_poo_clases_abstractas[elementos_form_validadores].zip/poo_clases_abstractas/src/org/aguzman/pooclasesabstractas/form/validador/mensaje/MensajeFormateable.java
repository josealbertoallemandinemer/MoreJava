package org.aguzman.pooclasesabstractas.form.validador.mensaje;

public interface MensajeFormateable {
    public String getMensajeFormateado(String campo);
}
