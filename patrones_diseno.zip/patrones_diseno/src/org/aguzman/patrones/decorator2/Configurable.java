package org.aguzman.patrones.decorator2;

public interface Configurable {
    float getPrecioBase();
    String getIngredientes();
}
