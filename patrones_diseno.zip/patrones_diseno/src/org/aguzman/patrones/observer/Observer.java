package org.aguzman.patrones.observer;

public interface Observer {
    void update(Observable observable, Object obj);
}
