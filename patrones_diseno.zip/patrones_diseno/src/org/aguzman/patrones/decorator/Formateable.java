package org.aguzman.patrones.decorator;

public interface Formateable {
    String darFormato();
}
